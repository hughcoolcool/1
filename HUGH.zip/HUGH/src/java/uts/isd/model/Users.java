package uts.isd.model;

import java.io.Serializable;

public class Users implements Serializable {
    
    private String ID;
    private String name;    
    private String email;
    private String address;    
    private String phone;    
    private String date;

    public Users(String ID, String name, String email, String address, String phone, String date) {
        this.ID = ID;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.date = date;
    }

    public Users() {}
    
    public void updateDetails(String name, String email, String address, String phone, String date){
        this.name = name;
        this.email = email;
        this.address = address;
        this.phone = phone;   
    }
    
    public boolean matchID(String ID){
        return this.ID.equals(ID.trim());
    }
    
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
}
