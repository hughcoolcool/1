package uts.isd.model.dao;

import uts.isd.model.Users;
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author truongviethoang
 */
public class DBManager {

    private Statement st;

    public DBManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    //Find Order by ID in the database
    public Users findUsers(String ID, String date) throws SQLException {
        //setup the select sql query string
        String searchQueryString = "select * from Users where ID='" + ID + "' AND date='" + date + "'";
        //execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a Order using the parameters
         boolean hasUsers = rs.next();
         Users UsersFromDB = null;
                 
         if(hasUsers){
         
             String sID = rs.getString("ID");
             String sName = rs.getString("name");
             String sDate = rs.getString("date"); 
             String sEmail = rs.getString("email");
             String sAddress = rs.getString("address");
             String sPhone = rs.getString("phone");
             
             UsersFromDB = new Users (sID, sName, sEmail, sAddress, sPhone, sDate);
         }
        
         rs.close();
        // st.close();
         
         return UsersFromDB;
         
    }

    //Check if a Order exist in the database
    public boolean checkUsers(String ID, String name) throws SQLException {
       //setup the select sql query string
        //execute this query using the statement field
        //add the results to a ResultSet
        //search the ResultSet for a Order using the parameters
        //verify if the Order exists
        return false;
    }

    //Add a Order-data into the database
    public void addUsers(String ID, String name, String email, String address, String phone, String date) throws SQLException {        
        //code for add-operation
        
         String createQueryString = "insert into Orders" + " values ('" + ID + "', '" + name + "', '" + email + "', '" + address + "', '" + phone + "', '" + date + "')";
         boolean recordCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recordCreated){
         System.out.println("record created");
         }
         else {
         System.out.println("record not created");
         }
             
    }

    //update a Order details in the database
    public void updateUsers(String ID, String name, String email, String address, String phone, String date) throws SQLException {
        //code for update-operation
        
        String updateQueryString = "update Users set name = '" + name + "', email= '" + email + "', address = '"  + address + "', phone = '" + phone + "', date = '" + date + "' where ID='" + ID + "'";
        boolean recordUpdated = st.executeUpdate(updateQueryString) > 0;
         
         if (recordUpdated){
         System.out.println("record updated");
         }
         else {
         System.out.println("record not updated");
         }
       
    }
    
    //delete a Order from the database
    public void deleteUsers(String ID) throws SQLException{
        //code for delete-operation
        
        String deleteQueryString = "delete from Users where ID= '" + ID + "' ";
        boolean recordDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recordDeleted){
         System.out.println("record deleted");
         }
         else {
         System.out.println("record not deleted");
         }
    }
}
